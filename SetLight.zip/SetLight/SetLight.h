#ifndef SetLight_H
#define SetLight_H

#include "Arduino.h" 

    class SetLight {

        public: 
            SetLight(int i);
            void Toggle();
            void Turn(bool Switch);
        private:
            void setled (bool states);
            int s;
            bool state;


    };

#endif