#include "Arduino.h"
#include "SetLight.h"

SetLight::SetLight(int i){
    s = i;
    state = false;
    pinMode(s, OUTPUT);
}

void SetLight::setled (bool states){
    digitalWrite(s, states);
}

void SetLight::Turn(bool Switch){
    setled(Switch);
    state = Switch;
}

void SetLight::Toggle(){
    state = !state;
    setled(state);
}