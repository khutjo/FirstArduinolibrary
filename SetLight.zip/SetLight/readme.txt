I in no way claim to know what i am doing with this library
and IMO you should be looking somewhere else if you want an led controller
but if you want to learn how this is done this can be really helpful
dont worry about copy right on this specifc code because _  O O  _
							  \ ~~~ /
							   
 